<?php

namespace App\Console\Commands;

use App\Models\ImportRun;
use App\Services\Import\ProductCsvImporter;
use Illuminate\Console\Command;
use Throwable;

class ImportProductsFromCsv extends Command
{
    protected $signature = 'products:import {path : Đường dẫn tới file CSV export sản phẩm}';

    protected $description = 'Import sản phẩm từ file CSV export (không gọi WooCommerce API)';

    public function handle(ProductCsvImporter $importer): int
    {
        $path = $this->argument('path');

        if (! is_file($path)) {
            $this->error("Không tìm thấy file: {$path}");

            return self::FAILURE;
        }

        $importRun = ImportRun::query()->create([
            'source' => 'csv_import',
            'status' => 'running',
            'started_at' => now(),
        ]);

        try {
            $summary = $importer->import($path);

            $importRun->update([
                'status' => $summary->isSuccess() ? 'success' : 'success_with_errors',
                'finished_at' => now(),
                'processed_count' => $summary->processedCount(),
                'success_count' => $summary->processedCount(),
                'failed_count' => $summary->skipped,
                'message' => $summary->errors !== [] ? implode("\n", $summary->errors) : null,
            ]);
        } catch (Throwable $exception) {
            $importRun->update([
                'status' => 'failed',
                'finished_at' => now(),
                'message' => $exception->getMessage(),
            ]);

            $this->error("Import thất bại: {$exception->getMessage()}");

            return self::FAILURE;
        }

        $this->info("Tổng số dòng: {$summary->totalRows}");
        $this->info("Tạo mới: {$summary->created}");
        $this->info("Cập nhật: {$summary->updated}");
        $this->info("Bỏ qua: {$summary->skipped}");

        if ($summary->errors !== []) {
            $this->warn('Các dòng lỗi:');

            foreach ($summary->errors as $error) {
                $this->line("  - {$error}");
            }
        }

        return self::SUCCESS;
    }
}
