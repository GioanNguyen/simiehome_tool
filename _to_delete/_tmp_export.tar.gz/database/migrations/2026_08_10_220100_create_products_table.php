<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('products', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('wordpress_product_id')->nullable()->index();
            $table->string('sku')->unique();
            $table->string('name')->index();
            $table->string('product_type')->default('other')->index();
            $table->decimal('base_price', 15, 2)->nullable();
            $table->string('status')->default('publish');
            $table->json('attributes_json')->nullable();
            $table->timestamp('last_synced_at')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('products');
    }
};
