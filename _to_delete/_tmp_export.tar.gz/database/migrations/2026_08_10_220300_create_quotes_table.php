<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('quotes', function (Blueprint $table) {
            $table->id();
            $table->string('quote_code')->unique();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->foreignId('table_product_id')->nullable()->constrained('products')->nullOnDelete();
            $table->string('table_sku')->nullable();
            $table->string('table_name')->nullable();
            $table->unsignedInteger('table_size_cm')->nullable();
            $table->decimal('manual_extra_fee', 15, 2)->default(0);
            $table->decimal('table_total', 15, 2)->default(0);
            $table->decimal('chair_1_total', 15, 2)->default(0);
            $table->decimal('chair_2_total', 15, 2)->default(0);
            $table->decimal('grand_total', 15, 2)->default(0);
            $table->text('notes')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('quotes');
    }
};
