<?php

namespace Database\Factories;

use App\Models\Product;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends Factory<Product>
 */
class ProductFactory extends Factory
{
    protected $model = Product::class;

    public function definition(): array
    {
        return [
            'wordpress_product_id' => fake()->unique()->numberBetween(1, 999999),
            'sku' => strtoupper(fake()->bothify('SKU-###??')),
            'name' => fake()->words(3, true),
            'product_type' => fake()->randomElement(['table', 'chair', 'other']),
            'base_price' => fake()->numberBetween(500_000, 5_000_000),
            'status' => 'publish',
            'attributes_json' => [],
            'last_synced_at' => now(),
        ];
    }
}
