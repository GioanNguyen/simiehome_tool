<x-app-layout>
    <x-slot name="header">
        <h2 class="text-xl font-semibold leading-tight text-gray-800">
            Tinh gia bo ban an
        </h2>
    </x-slot>

    <div class="py-8">
        <div class="mx-auto max-w-5xl space-y-6 px-4 sm:px-6 lg:px-8">
            <div class="rounded-lg bg-white p-6 shadow">
                <p class="text-sm text-gray-600">Nhap nhanh thong tin ban, ghe va phi rieng de luu bao gia.</p>

                <form method="POST" action="{{ route('quotes.store') }}" class="mt-6 grid gap-4 md:grid-cols-2">
                    @csrf

                    <div class="md:col-span-2">
                        <label for="table_product_id" class="block text-sm font-medium text-gray-700">Ban</label>
                        <select id="table_product_id" name="table_product_id" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm">
                            <option value="">Chon san pham ban</option>
                            @foreach (\App\Models\Product::query()->where('product_type', 'table')->orderBy('name')->limit(50)->get() as $product)
                                <option value="{{ $product->id }}">{{ $product->name }} - {{ $product->sku }}</option>
                            @endforeach
                        </select>
                    </div>

                    <div>
                        <label for="table_size_cm" class="block text-sm font-medium text-gray-700">Kich thuoc ban (cm)</label>
                        <input id="table_size_cm" name="table_size_cm" type="number" min="1" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm">
                    </div>

                    <div>
                        <label for="manual_extra_fee" class="block text-sm font-medium text-gray-700">Phi rieng</label>
                        <input id="manual_extra_fee" name="manual_extra_fee" type="number" min="0" value="0" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm">
                    </div>

                    <div>
                        <label for="chair_1_product_id" class="block text-sm font-medium text-gray-700">Ghe loai 1</label>
                        <select id="chair_1_product_id" name="chair_1_product_id" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm">
                            <option value="">Chon ghe</option>
                            @foreach (\App\Models\Product::query()->where('product_type', 'chair')->orderBy('name')->limit(50)->get() as $product)
                                <option value="{{ $product->id }}">{{ $product->name }} - {{ $product->sku }}</option>
                            @endforeach
                        </select>
                    </div>

                    <div>
                        <label for="chair_1_quantity" class="block text-sm font-medium text-gray-700">So luong ghe loai 1</label>
                        <input id="chair_1_quantity" name="chair_1_quantity" type="number" min="0" value="0" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm">
                    </div>

                    <div>
                        <label for="chair_2_product_id" class="block text-sm font-medium text-gray-700">Ghe loai 2</label>
                        <select id="chair_2_product_id" name="chair_2_product_id" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm">
                            <option value="">Chon ghe</option>
                            @foreach (\App\Models\Product::query()->where('product_type', 'chair')->orderBy('name')->limit(50)->get() as $product)
                                <option value="{{ $product->id }}">{{ $product->name }} - {{ $product->sku }}</option>
                            @endforeach
                        </select>
                    </div>

                    <div>
                        <label for="chair_2_quantity" class="block text-sm font-medium text-gray-700">So luong ghe loai 2</label>
                        <input id="chair_2_quantity" name="chair_2_quantity" type="number" min="0" value="0" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm">
                    </div>

                    <div class="md:col-span-2">
                        <label for="notes" class="block text-sm font-medium text-gray-700">Ghi chu</label>
                        <textarea id="notes" name="notes" rows="3" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm"></textarea>
                    </div>

                    <div class="md:col-span-2">
                        <button type="submit" class="inline-flex rounded-md bg-orange-600 px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-orange-500">
                            Luu bao gia
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</x-app-layout>
