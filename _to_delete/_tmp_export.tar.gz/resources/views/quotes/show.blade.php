<x-app-layout>
    <x-slot name="header">
        <h2 class="text-xl font-semibold leading-tight text-gray-800">
            Bao gia {{ $quote->quote_code }}
        </h2>
    </x-slot>

    <div class="py-8">
        <div class="mx-auto max-w-4xl space-y-6 px-4 sm:px-6 lg:px-8">
            <div class="rounded-lg bg-white p-6 shadow">
                <dl class="grid gap-4 md:grid-cols-2">
                    <div>
                        <dt class="text-sm text-gray-500">Ban</dt>
                        <dd class="text-base font-medium text-gray-900">{{ $quote->table_name ?? 'N/A' }}</dd>
                    </div>
                    <div>
                        <dt class="text-sm text-gray-500">Tong gia</dt>
                        <dd class="text-base font-medium text-gray-900">{{ number_format((float) $quote->grand_total, 0, ',', '.') }}</dd>
                    </div>
                </dl>
            </div>
        </div>
    </div>
</x-app-layout>
