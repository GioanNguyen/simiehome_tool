<x-app-layout>
    <x-slot name="header">
        <h2 class="text-xl font-semibold leading-tight text-gray-800">
            Pricing rules
        </h2>
    </x-slot>

    <div class="py-8">
        <div class="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
            <div class="rounded-lg bg-white p-6 shadow">
                <div class="space-y-4">
                    @forelse ($pricingRules as $pricingRule)
                        <form method="POST" action="{{ route('admin.pricing-rules.update', $pricingRule) }}" class="grid gap-4 border-b border-gray-100 pb-4 md:grid-cols-5">
                            @csrf
                            @method('PATCH')

                            <div>
                                <p class="text-sm font-medium text-gray-900">{{ $pricingRule->sku }}</p>
                                <p class="text-xs text-gray-500">{{ $pricingRule->product?->name }}</p>
                            </div>

                            <div>
                                <label class="block text-xs font-medium text-gray-500">Applies to</label>
                                <p class="mt-2 text-sm text-gray-900">{{ $pricingRule->applies_to }}</p>
                            </div>

                            <div>
                                <label for="surcharge_amount_{{ $pricingRule->id }}" class="block text-xs font-medium text-gray-500">Surcharge</label>
                                <input id="surcharge_amount_{{ $pricingRule->id }}" name="surcharge_amount" type="number" min="0" value="{{ (float) $pricingRule->surcharge_amount }}" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm">
                            </div>

                            <label class="flex items-center gap-2 pt-6 text-sm text-gray-700">
                                <input type="checkbox" name="active" value="1" @checked($pricingRule->active)>
                                Active
                            </label>

                            <div class="pt-5">
                                <button type="submit" class="inline-flex rounded-md bg-orange-600 px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-orange-500">
                                    Save
                                </button>
                            </div>
                        </form>
                    @empty
                        <p class="text-sm text-gray-500">No pricing rules yet.</p>
                    @endforelse
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
