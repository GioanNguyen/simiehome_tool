<?php

namespace App\Domain\Pricing;

final class QuoteCalculationResult
{
    public function __construct(
        public readonly float $tableTotal,
        public readonly float $chair1Total,
        public readonly float $chair2Total,
        public readonly float $manualExtraFee,
        public readonly float $grandTotal,
    ) {
    }
}
