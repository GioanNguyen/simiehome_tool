<?php

namespace App\Domain\Pricing;

final class QuoteCalculator
{
    public function calculate(array $payload): QuoteCalculationResult
    {
        $tableTotal = ($this->floatValue($payload['table_base_price'] ?? null) * $this->floatValue($payload['table_size_cm'] ?? null) / 100)
            + $this->floatValue($payload['table_surcharge'] ?? null);

        $chair1Total = $this->floatValue($payload['chair_1_base_price'] ?? null) * $this->floatValue($payload['chair_1_quantity'] ?? null);
        $chair2Total = $this->floatValue($payload['chair_2_base_price'] ?? null) * $this->floatValue($payload['chair_2_quantity'] ?? null);
        $manualExtraFee = $this->floatValue($payload['manual_extra_fee'] ?? null);

        return new QuoteCalculationResult(
            tableTotal: $tableTotal,
            chair1Total: $chair1Total,
            chair2Total: $chair2Total,
            manualExtraFee: $manualExtraFee,
            grandTotal: $tableTotal + $chair1Total + $chair2Total + $manualExtraFee,
        );
    }

    private function floatValue(mixed $value): float
    {
        return is_numeric($value) ? (float) $value : 0.0;
    }
}
