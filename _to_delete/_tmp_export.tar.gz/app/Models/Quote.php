<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Quote extends Model
{
    protected $fillable = [
        'quote_code',
        'user_id',
        'table_product_id',
        'table_sku',
        'table_name',
        'table_size_cm',
        'manual_extra_fee',
        'table_total',
        'chair_1_total',
        'chair_2_total',
        'grand_total',
        'notes',
    ];

    protected function casts(): array
    {
        return [
            'table_size_cm' => 'integer',
            'manual_extra_fee' => 'decimal:2',
            'table_total' => 'decimal:2',
            'chair_1_total' => 'decimal:2',
            'chair_2_total' => 'decimal:2',
            'grand_total' => 'decimal:2',
        ];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function items(): HasMany
    {
        return $this->hasMany(QuoteItem::class);
    }
}
