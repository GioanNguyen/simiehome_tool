<?php

namespace App\Models;

use Database\Factories\ProductFactory;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Product extends Model
{
    /** @use HasFactory<ProductFactory> */
    use HasFactory;

    protected $fillable = [
        'wordpress_product_id',
        'sku',
        'name',
        'product_type',
        'base_price',
        'status',
        'attributes_json',
        'last_synced_at',
    ];

    protected function casts(): array
    {
        return [
            'base_price' => 'decimal:2',
            'attributes_json' => 'array',
            'last_synced_at' => 'datetime',
        ];
    }

    public function pricingRules(): HasMany
    {
        return $this->hasMany(ProductPricingRule::class);
    }
}
