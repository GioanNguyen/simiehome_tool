<?php

namespace App\Jobs;

use App\Models\Product;
use App\Models\SyncRun;
use App\Services\WooCommerce\WooCommerceClient;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Queue\Queueable;
use Throwable;

class SyncWooCommerceProductsJob implements ShouldQueue
{
    use Queueable;

    public function handle(WooCommerceClient $client): void
    {
        $syncRun = SyncRun::query()->create([
            'source' => 'woocommerce',
            'status' => 'running',
            'started_at' => now(),
        ]);

        try {
            $products = $client->fetchProducts();

            foreach ($products as $product) {
                Product::query()->updateOrCreate(
                    ['sku' => $product['sku']],
                    [
                        'wordpress_product_id' => $product['id'] ?? null,
                        'name' => $product['name'] ?? $product['sku'],
                        'product_type' => $this->inferProductType($product),
                        'base_price' => $product['price'] ?? 0,
                        'status' => $product['status'] ?? 'publish',
                        'attributes_json' => $product['attributes'] ?? [],
                        'last_synced_at' => now(),
                    ],
                );
            }

            $count = count($products);

            $syncRun->update([
                'status' => 'success',
                'finished_at' => now(),
                'processed_count' => $count,
                'success_count' => $count,
                'failed_count' => 0,
            ]);
        } catch (Throwable $exception) {
            $syncRun->update([
                'status' => 'failed',
                'finished_at' => now(),
                'message' => $exception->getMessage(),
            ]);

            throw $exception;
        }
    }

    private function inferProductType(array $product): string
    {
        $name = strtolower((string) ($product['name'] ?? ''));

        if (str_contains($name, 'ghe')) {
            return 'chair';
        }

        if (str_contains($name, 'ban')) {
            return 'table';
        }

        return 'other';
    }
}
