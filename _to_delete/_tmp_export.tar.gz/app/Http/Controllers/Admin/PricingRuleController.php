<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\ProductPricingRule;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class PricingRuleController extends Controller
{
    public function index(): View
    {
        return view('admin.pricing-rules.index', [
            'pricingRules' => ProductPricingRule::query()
                ->with('product')
                ->orderBy('sku')
                ->get(),
        ]);
    }

    public function update(Request $request, ProductPricingRule $pricingRule): RedirectResponse
    {
        $validated = $request->validate([
            'surcharge_amount' => ['required', 'numeric', 'min:0'],
            'active' => ['nullable', 'boolean'],
        ]);

        $pricingRule->update([
            'surcharge_amount' => $validated['surcharge_amount'],
            'active' => (bool) ($validated['active'] ?? false),
        ]);

        return redirect()->route('admin.pricing-rules.index');
    }
}
