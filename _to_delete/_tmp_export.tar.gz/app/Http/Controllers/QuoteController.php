<?php

namespace App\Http\Controllers;

use App\Domain\Pricing\QuoteCalculator;
use App\Models\Product;
use App\Models\Quote;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\View\View;

class QuoteController extends Controller
{
    public function __construct(
        private readonly QuoteCalculator $calculator,
    ) {
    }

    public function index(): View
    {
        return view('quotes.index');
    }

    public function show(Quote $quote): View
    {
        $quote->load('items');

        return view('quotes.show', [
            'quote' => $quote,
        ]);
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'table_product_id' => ['nullable', 'exists:products,id'],
            'table_size_cm' => ['nullable', 'integer', 'min:1'],
            'chair_1_product_id' => ['nullable', 'exists:products,id'],
            'chair_1_quantity' => ['nullable', 'integer', 'min:0'],
            'chair_2_product_id' => ['nullable', 'exists:products,id'],
            'chair_2_quantity' => ['nullable', 'integer', 'min:0'],
            'manual_extra_fee' => ['nullable', 'numeric', 'min:0'],
            'notes' => ['nullable', 'string'],
        ]);

        $table = isset($validated['table_product_id'])
            ? Product::query()->with('pricingRules')->find($validated['table_product_id'])
            : null;

        $chair1 = isset($validated['chair_1_product_id'])
            ? Product::query()->find($validated['chair_1_product_id'])
            : null;

        $chair2 = isset($validated['chair_2_product_id'])
            ? Product::query()->find($validated['chair_2_product_id'])
            : null;

        $tableSurcharge = $table?->pricingRules()
            ->where('active', true)
            ->whereIn('applies_to', ['table', 'all'])
            ->sum('surcharge_amount') ?? 0;

        $result = $this->calculator->calculate([
            'table_base_price' => $table?->base_price,
            'table_size_cm' => $validated['table_size_cm'] ?? null,
            'table_surcharge' => $tableSurcharge,
            'chair_1_base_price' => $chair1?->base_price,
            'chair_1_quantity' => $validated['chair_1_quantity'] ?? 0,
            'chair_2_base_price' => $chair2?->base_price,
            'chair_2_quantity' => $validated['chair_2_quantity'] ?? 0,
            'manual_extra_fee' => $validated['manual_extra_fee'] ?? 0,
        ]);

        $quote = DB::transaction(function () use ($request, $validated, $table, $chair1, $chair2, $result) {
            $quote = Quote::query()->create([
                'quote_code' => 'QT-'.Str::upper(Str::random(8)),
                'user_id' => $request->user()->id,
                'table_product_id' => $table?->id,
                'table_sku' => $table?->sku,
                'table_name' => $table?->name,
                'table_size_cm' => $validated['table_size_cm'] ?? null,
                'manual_extra_fee' => $result->manualExtraFee,
                'table_total' => $result->tableTotal,
                'chair_1_total' => $result->chair1Total,
                'chair_2_total' => $result->chair2Total,
                'grand_total' => $result->grandTotal,
                'notes' => $validated['notes'] ?? null,
            ]);

            if ($chair1 !== null) {
                $quote->items()->create([
                    'item_role' => 'chair_type_1',
                    'product_id' => $chair1->id,
                    'sku' => $chair1->sku,
                    'product_name' => $chair1->name,
                    'unit_price' => $chair1->base_price,
                    'quantity' => $validated['chair_1_quantity'] ?? 0,
                    'line_total' => $result->chair1Total,
                ]);
            }

            if ($chair2 !== null) {
                $quote->items()->create([
                    'item_role' => 'chair_type_2',
                    'product_id' => $chair2->id,
                    'sku' => $chair2->sku,
                    'product_name' => $chair2->name,
                    'unit_price' => $chair2->base_price,
                    'quantity' => $validated['chair_2_quantity'] ?? 0,
                    'line_total' => $result->chair2Total,
                ]);
            }

            if ($result->manualExtraFee > 0) {
                $quote->items()->create([
                    'item_role' => 'manual_fee',
                    'quantity' => 1,
                    'line_total' => $result->manualExtraFee,
                    'meta_json' => ['label' => 'Manual extra fee'],
                ]);
            }

            return $quote;
        });

        return redirect()->route('quotes.show', $quote);
    }
}
