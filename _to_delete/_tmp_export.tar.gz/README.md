# Quotation Tool

Laravel tool noi bo de sales/admin tinh nhanh gia bo ban an, dong bo san pham tu WooCommerce, va luu lich su bao gia.

## Requirements

- PHP 8.3
- Composer
- Node.js + npm
- MySQL cho production; SQLite co the dung cho local/test nhanh

## Features

- Dang nhap noi bo bang Laravel Breeze
- Tim san pham theo `name` hoac `sku`
- Tinh gia bo ban an theo cong thuc da chot
- Luu snapshot bao gia vao `quotes` va `quote_items`
- Dong bo catalog WooCommerce vao database Laravel
- Quan ly sync runs va pricing rules trong admin

## Local Setup

1. `composer install`
2. `cp .env.example .env`
3. `php artisan key:generate`
4. `touch database/database.sqlite`
5. `php artisan migrate`
6. `npm install`
7. `npm run build`
8. `php artisan serve`

## WooCommerce Config

Cap nhat cac bien sau trong `.env`:

```dotenv
WOOCOMMERCE_BASE_URL=https://your-site.com
WOOCOMMERCE_KEY=ck_xxxxx
WOOCOMMERCE_SECRET=cs_xxxxx
```

## Main Routes

- `/quotes`: man hinh tao bao gia
- `/products/search`: endpoint JSON cho goi y san pham
- `/admin/sync-runs`: xem va chay sync WooCommerce
- `/admin/pricing-rules`: chinh phu phi theo SKU

## Verification

- `php artisan test`
- `npm run build`
