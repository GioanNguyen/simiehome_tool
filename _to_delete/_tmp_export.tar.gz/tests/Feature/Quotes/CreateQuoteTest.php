<?php

namespace Tests\Feature\Quotes;

use App\Models\Product;
use App\Models\ProductPricingRule;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class CreateQuoteTest extends TestCase
{
    use RefreshDatabase;

    public function test_it_shows_the_quote_calculator_page_to_authenticated_users(): void
    {
        $this->actingAs(User::factory()->create())
            ->get(route('quotes.index'))
            ->assertOk()
            ->assertSee('Tinh gia bo ban an');
    }

    public function test_it_stores_a_quote_snapshot_with_calculated_totals(): void
    {
        $user = User::factory()->create();

        $table = Product::factory()->create([
            'sku' => 'BAN-140',
            'name' => 'Ban 1m4',
            'product_type' => 'table',
            'base_price' => 4_000_000,
        ]);

        $chair = Product::factory()->create([
            'sku' => 'GHE-A',
            'name' => 'Ghe A',
            'product_type' => 'chair',
            'base_price' => 1_000_000,
        ]);

        ProductPricingRule::query()->create([
            'product_id' => $table->id,
            'sku' => 'BAN-140',
            'applies_to' => 'table',
            'surcharge_amount' => 500_000,
            'active' => true,
        ]);

        $this->actingAs($user)
            ->post(route('quotes.store'), [
                'table_product_id' => $table->id,
                'table_size_cm' => 140,
                'chair_1_product_id' => $chair->id,
                'chair_1_quantity' => 4,
                'manual_extra_fee' => 300_000,
            ])
            ->assertRedirect();

        $this->assertDatabaseHas('quotes', [
            'user_id' => $user->id,
            'table_sku' => 'BAN-140',
            'table_name' => 'Ban 1m4',
            'grand_total' => 10_400_000.00,
        ]);

        $this->assertDatabaseHas('quote_items', [
            'item_role' => 'chair_type_1',
            'sku' => 'GHE-A',
            'quantity' => 4,
            'line_total' => 4_000_000.00,
        ]);
    }
}
