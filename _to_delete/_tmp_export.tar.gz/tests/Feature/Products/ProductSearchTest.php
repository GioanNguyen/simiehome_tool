<?php

namespace Tests\Feature\Products;

use App\Models\Product;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class ProductSearchTest extends TestCase
{
    use RefreshDatabase;

    public function test_it_returns_matching_products_by_name_or_sku(): void
    {
        $user = User::factory()->create();

        Product::factory()->create([
            'sku' => 'BAN-140',
            'name' => 'Ban 1m4',
            'product_type' => 'table',
            'base_price' => 4_000_000,
        ]);

        Product::factory()->create([
            'sku' => 'GHE-A',
            'name' => 'Ghe A',
            'product_type' => 'chair',
            'base_price' => 1_000_000,
        ]);

        $response = $this
            ->actingAs($user)
            ->getJson(route('products.search', ['q' => 'BAN']));

        $response
            ->assertOk()
            ->assertJsonFragment([
                'sku' => 'BAN-140',
                'name' => 'Ban 1m4',
            ])
            ->assertJsonMissing([
                'sku' => 'GHE-A',
            ]);
    }
}
