<?php

namespace Tests\Unit\Domain\Pricing;

use App\Domain\Pricing\QuoteCalculator;
use PHPUnit\Framework\TestCase;

class QuoteCalculatorTest extends TestCase
{
    public function test_it_calculates_a_table_total_using_size_and_surcharge(): void
    {
        $calculator = new QuoteCalculator();

        $result = $calculator->calculate([
            'table_base_price' => 4_000_000,
            'table_size_cm' => 140,
            'table_surcharge' => 500_000,
            'chair_1_base_price' => 0,
            'chair_1_quantity' => 0,
            'chair_2_base_price' => 0,
            'chair_2_quantity' => 0,
            'manual_extra_fee' => 0,
        ]);

        $this->assertSame(6_100_000.0, $result->tableTotal);
        $this->assertSame(6_100_000.0, $result->grandTotal);
    }

    public function test_it_adds_chair_totals_and_manual_fees_into_the_grand_total(): void
    {
        $calculator = new QuoteCalculator();

        $result = $calculator->calculate([
            'table_base_price' => 4_000_000,
            'table_size_cm' => 140,
            'table_surcharge' => 500_000,
            'chair_1_base_price' => 1_000_000,
            'chair_1_quantity' => 4,
            'chair_2_base_price' => 500_000,
            'chair_2_quantity' => 2,
            'manual_extra_fee' => 300_000,
        ]);

        $this->assertSame(11_400_000.0, $result->grandTotal);
        $this->assertSame(4_000_000.0, $result->chair1Total);
        $this->assertSame(1_000_000.0, $result->chair2Total);
    }
}
