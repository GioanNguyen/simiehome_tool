<?php

namespace Tests\Feature\Quotes;

use App\Models\Product;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class CreateQuoteTest extends TestCase
{
    use RefreshDatabase;

    public function test_it_shows_the_quote_calculator_page_to_authenticated_users(): void
    {
        $this->actingAs(User::factory()->create())
            ->get(route('quotes.index'))
            ->assertOk()
            ->assertSee('Tính giá bộ nội thất');
    }

    public function test_it_stores_a_quote_with_a_main_item_any_number_of_addons_and_fees(): void
    {
        $user = User::factory()->create();

        $table = Product::factory()->create([
            'sku' => 'BAN-140',
            'name' => 'Ban 1m4',
            'regular_price' => 4_000_000,
            'sale_price' => null,
        ]);

        $chairA = Product::factory()->create(['sku' => 'GHE-A', 'regular_price' => 1_000_000, 'sale_price' => null]);
        $chairB = Product::factory()->create(['sku' => 'GHE-B', 'regular_price' => 500_000, 'sale_price' => null]);
        $mirror = Product::factory()->create(['sku' => 'GUONG-A', 'regular_price' => 200_000, 'sale_price' => null]);

        $this->actingAs($user)
            ->post(route('quotes.store'), [
                'main' => ['product_id' => $table->id, 'quantity' => 1],
                'addons' => [
                    ['product_id' => $chairA->id, 'quantity' => 4],
                    ['product_id' => $chairB->id, 'quantity' => 2],
                    ['product_id' => $mirror->id, 'quantity' => 1],
                ],
                'fees' => [
                    ['label' => 'Phí ship', 'amount' => 300_000],
                    ['label' => 'Phí lắp đặt', 'amount' => 200_000],
                ],
            ])
            ->assertRedirect();

        // 4_000_000 + (1_000_000*4) + (500_000*2) + 200_000 = 9_200_000 subtotal
        // + 500_000 fees = 9_700_000
        $this->assertDatabaseHas('quotes', [
            'user_id' => $user->id,
            'subtotal' => 9_200_000.00,
            'fee_total' => 500_000.00,
            'grand_total' => 9_700_000.00,
        ]);

        $this->assertDatabaseHas('quote_items', [
            'role' => 'main',
            'sku' => 'BAN-140',
            'quantity' => 1,
            'line_total' => 4_000_000.00,
        ]);

        $this->assertDatabaseHas('quote_items', [
            'role' => 'addon',
            'sku' => 'GHE-A',
            'quantity' => 4,
            'line_total' => 4_000_000.00,
        ]);

        $this->assertDatabaseHas('quote_items', [
            'role' => 'addon',
            'sku' => 'GUONG-A',
            'quantity' => 1,
            'line_total' => 200_000.00,
        ]);

        $this->assertDatabaseHas('quote_items', [
            'role' => 'fee',
            'product_name' => 'Phí ship',
            'line_total' => 300_000.00,
        ]);

        // main + 3 addons + 2 fees
        $this->assertDatabaseCount('quote_items', 6);
    }

    public function test_it_allows_a_quote_with_only_addons_and_no_main_product(): void
    {
        $user = User::factory()->create();
        $chair = Product::factory()->create(['sku' => 'GHE-A', 'regular_price' => 1_000_000, 'sale_price' => null]);

        $this->actingAs($user)
            ->post(route('quotes.store'), [
                'addons' => [
                    ['product_id' => $chair->id, 'quantity' => 2],
                ],
            ])
            ->assertRedirect();

        $this->assertDatabaseHas('quotes', [
            'user_id' => $user->id,
            'subtotal' => 2_000_000.00,
        ]);

        $this->assertDatabaseMissing('quote_items', ['role' => 'main']);
    }
}
