<?php

namespace Tests\Feature\Admin;

use App\Models\PricingRule;
use App\Models\Product;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class PricingRuleTest extends TestCase
{
    use RefreshDatabase;

    public function test_it_shows_pricing_rules_to_authenticated_users(): void
    {
        PricingRule::query()->create([
            'category' => 'Bàn - Tables',
            'formula_type' => 'length_ratio',
            'surcharge_amount' => 500_000,
            'active' => true,
        ]);

        $this->actingAs(User::factory()->create())
            ->get(route('admin.pricing-rules.index'))
            ->assertOk()
            ->assertSee('Bàn - Tables')
            ->assertSee('length_ratio');
    }

    public function test_it_creates_a_category_level_rule(): void
    {
        $this->actingAs(User::factory()->create())
            ->post(route('admin.pricing-rules.store'), [
                'category' => 'Ghế - Chairs',
                'formula_type' => 'quantity',
                'surcharge_amount' => 0,
            ])
            ->assertRedirect(route('admin.pricing-rules.index'));

        $this->assertDatabaseHas('pricing_rules', [
            'category' => 'Ghế - Chairs',
            'product_id' => null,
            'formula_type' => 'quantity',
        ]);
    }

    public function test_it_creates_a_product_level_override_rule(): void
    {
        $product = Product::factory()->create();

        $this->actingAs(User::factory()->create())
            ->post(route('admin.pricing-rules.store'), [
                'product_id' => $product->id,
                'formula_type' => 'fixed',
                'surcharge_amount' => 0,
            ])
            ->assertRedirect(route('admin.pricing-rules.index'));

        $this->assertDatabaseHas('pricing_rules', [
            'product_id' => $product->id,
            'category' => null,
            'formula_type' => 'fixed',
        ]);
    }

    public function test_it_updates_an_existing_rule(): void
    {
        $rule = PricingRule::query()->create([
            'category' => 'Bàn - Tables',
            'formula_type' => 'length_ratio',
            'surcharge_amount' => 500_000,
            'active' => true,
        ]);

        $this->actingAs(User::factory()->create())
            ->patch(route('admin.pricing-rules.update', $rule), [
                'formula_type' => 'length_ratio',
                'surcharge_amount' => 750_000,
                'active' => false,
            ])
            ->assertRedirect(route('admin.pricing-rules.index'));

        $this->assertDatabaseHas('pricing_rules', [
            'id' => $rule->id,
            'surcharge_amount' => 750_000.00,
            'active' => 0,
        ]);
    }
}
