<?php

namespace Tests\Unit\Services\Import;

use App\Models\Product;
use App\Services\Import\ProductCsvImporter;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class ProductCsvImporterTest extends TestCase
{
    use RefreshDatabase;

    public function test_it_imports_products_and_skips_rows_missing_required_fields(): void
    {
        $summary = (new ProductCsvImporter)->import(
            base_path('tests/Fixtures/sample-products.csv'),
        );

        $this->assertSame(7, $summary->totalRows);
        $this->assertSame(6, $summary->created);
        $this->assertSame(1, $summary->skipped);
        $this->assertCount(1, $summary->errors);

        $this->assertDatabaseCount('products', 6);
    }

    public function test_it_uses_external_id_not_sku_as_the_mapping_key(): void
    {
        (new ProductCsvImporter)->import(base_path('tests/Fixtures/sample-products.csv'));

        $mirror = Product::query()->where('external_id', 1)->first();

        $this->assertSame('GUONG-A', $mirror->sku);
        $this->assertSame('simple', $mirror->type);
        $this->assertSame('Trang trí & gia dụng', $mirror->category);
        $this->assertSame(1040000.0, (float) $mirror->sale_price);
    }

    public function test_it_inherits_category_for_a_variation_referenced_by_parent_id(): void
    {
        (new ProductCsvImporter)->import(base_path('tests/Fixtures/sample-products.csv'));

        $variation = Product::query()->where('external_id', 3)->first();

        $this->assertSame('variation', $variation->type);
        $this->assertSame(2, $variation->parent_external_id);
        $this->assertSame('Bàn - Tables', $variation->category);
        $this->assertSame(['Size' => '120x60x75'], $variation->attributes_json);
    }

    public function test_it_inherits_category_for_a_variation_referenced_by_parent_sku(): void
    {
        (new ProductCsvImporter)->import(base_path('tests/Fixtures/sample-products.csv'));

        $parent = Product::query()->where('external_id', 4)->first();
        $variation = Product::query()->where('external_id', 5)->first();

        $this->assertSame($parent->external_id, $variation->parent_external_id);
        $this->assertSame('Ghế - Chairs', $variation->category);
    }

    public function test_it_marks_unpublished_rows_as_draft(): void
    {
        (new ProductCsvImporter)->import(base_path('tests/Fixtures/sample-products.csv'));

        $draft = Product::query()->where('external_id', 6)->first();

        $this->assertSame('draft', $draft->status);
    }

    public function test_reimporting_the_same_file_updates_instead_of_duplicating(): void
    {
        $importer = new ProductCsvImporter;
        $importer->import(base_path('tests/Fixtures/sample-products.csv'));
        $summary = $importer->import(base_path('tests/Fixtures/sample-products.csv'));

        $this->assertSame(0, $summary->created);
        $this->assertSame(6, $summary->updated);
        $this->assertDatabaseCount('products', 6);
    }
}
