<?php

use App\Http\Controllers\Admin\PricingRuleController;
use App\Http\Controllers\Admin\ProductImportController;
use App\Http\Controllers\Admin\SyncRunController;
use App\Http\Controllers\ProductSearchController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\QuoteController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/products/search', ProductSearchController::class)->name('products.search');
    Route::get('/quotes', [QuoteController::class, 'index'])->name('quotes.index');
    Route::post('/quotes', [QuoteController::class, 'store'])->name('quotes.store');
    Route::get('/quotes/{quote}', [QuoteController::class, 'show'])->name('quotes.show');

    Route::get('/admin/sync-runs', [SyncRunController::class, 'index'])->name('admin.sync-runs.index');
    Route::post('/admin/sync-runs', [SyncRunController::class, 'store'])->name('admin.sync-runs.store');

    Route::get('/admin/product-imports', [ProductImportController::class, 'index'])->name('admin.product-imports.index');
    Route::post('/admin/product-imports', [ProductImportController::class, 'store'])->name('admin.product-imports.store');

    Route::get('/admin/pricing-rules', [PricingRuleController::class, 'index'])->name('admin.pricing-rules.index');
    Route::post('/admin/pricing-rules', [PricingRuleController::class, 'store'])->name('admin.pricing-rules.store');
    Route::patch('/admin/pricing-rules/{pricingRule}', [PricingRuleController::class, 'update'])->name('admin.pricing-rules.update');

    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__.'/auth.php';
