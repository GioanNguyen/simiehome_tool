<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\PricingRule;
use App\Models\Product;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class PricingRuleController extends Controller
{
    public const FORMULA_TYPES = ['catalog_price', 'length_ratio', 'fixed', 'quantity'];

    public function index(): View
    {
        return view('admin.pricing-rules.index', [
            'pricingRules' => PricingRule::query()
                ->with('product')
                ->orderByRaw('category is null')
                ->orderBy('category')
                ->orderBy('id')
                ->get(),
            'categories' => Product::query()
                ->whereNotNull('category')
                ->distinct()
                ->orderBy('category')
                ->pluck('category'),
            'formulaTypes' => self::FORMULA_TYPES,
        ]);
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'category' => ['nullable', 'string'],
            'product_id' => ['nullable', 'exists:products,id'],
            'formula_type' => ['required', 'in:'.implode(',', self::FORMULA_TYPES)],
            'surcharge_amount' => ['required', 'numeric', 'min:0'],
            'notes' => ['nullable', 'string'],
        ]);

        PricingRule::query()->create([
            'category' => ($validated['product_id'] ?? null) ? null : ($validated['category'] ?? null),
            'product_id' => $validated['product_id'] ?? null,
            'formula_type' => $validated['formula_type'],
            'surcharge_amount' => $validated['surcharge_amount'],
            'notes' => $validated['notes'] ?? null,
            'active' => true,
        ]);

        return redirect()->route('admin.pricing-rules.index');
    }

    public function update(Request $request, PricingRule $pricingRule): RedirectResponse
    {
        $validated = $request->validate([
            'formula_type' => ['required', 'in:'.implode(',', self::FORMULA_TYPES)],
            'surcharge_amount' => ['required', 'numeric', 'min:0'],
            'active' => ['nullable', 'boolean'],
        ]);

        $pricingRule->update([
            'formula_type' => $validated['formula_type'],
            'surcharge_amount' => $validated['surcharge_amount'],
            'active' => (bool) ($validated['active'] ?? false),
        ]);

        return redirect()->route('admin.pricing-rules.index');
    }
}
