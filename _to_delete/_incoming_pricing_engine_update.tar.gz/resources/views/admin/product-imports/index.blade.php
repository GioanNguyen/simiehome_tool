<x-app-layout>
    <x-slot name="header">
        <h2 class="text-xl font-semibold leading-tight text-gray-800">
            Import sản phẩm từ CSV
        </h2>
    </x-slot>

    <div class="py-8">
        <div class="mx-auto max-w-5xl space-y-6 px-4 sm:px-6 lg:px-8">
            <div class="rounded-lg bg-white p-6 shadow">
                <p class="text-sm text-gray-600">
                    Tải lên file CSV export sản phẩm (định dạng export chuẩn của WooCommerce). Sản phẩm được ghi/khớp theo
                    cột <strong>ID</strong> trong file — SKU chỉ dùng để hiển thị, không dùng để mapping vì nhiều dòng
                    không có SKU.
                </p>

                <form method="POST" action="{{ route('admin.product-imports.store') }}" enctype="multipart/form-data" class="mt-4 flex flex-wrap items-end gap-4">
                    @csrf

                    <div>
                        <label class="block text-sm font-medium text-gray-700">File CSV</label>
                        <input type="file" name="file" accept=".csv,text/csv" required class="mt-1 block w-full text-sm">
                        @error('file')
                            <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                        @enderror
                    </div>

                    <button type="submit" class="inline-flex rounded-md bg-slate-900 px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-slate-700">
                        Import
                    </button>
                </form>
            </div>

            <div class="rounded-lg bg-white p-6 shadow">
                <h3 class="text-sm font-semibold uppercase tracking-wide text-gray-500">Lịch sử import</h3>

                <div class="mt-3 overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200 text-sm">
                        <thead>
                            <tr class="text-left text-gray-500">
                                <th class="py-2 pr-4">Thời gian</th>
                                <th class="py-2 pr-4">Trạng thái</th>
                                <th class="py-2 pr-4">Đã xử lý</th>
                                <th class="py-2 pr-4">Bỏ qua</th>
                                <th class="py-2 pr-4">Ghi chú</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-100">
                            @forelse ($importRuns as $importRun)
                                <tr>
                                    <td class="py-2 pr-4">{{ $importRun->created_at?->format('d/m/Y H:i') }}</td>
                                    <td class="py-2 pr-4">{{ $importRun->status }}</td>
                                    <td class="py-2 pr-4">{{ $importRun->processed_count }}</td>
                                    <td class="py-2 pr-4">{{ $importRun->failed_count }}</td>
                                    <td class="py-2 pr-4 max-w-md truncate" title="{{ $importRun->message }}">{{ $importRun->message }}</td>
                                </tr>
                            @empty
                                <tr>
                                    <td colspan="5" class="py-4 text-gray-500">Chưa có lần import nào.</td>
                                </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
