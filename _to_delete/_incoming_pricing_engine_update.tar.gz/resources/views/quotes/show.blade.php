<x-app-layout>
    <x-slot name="header">
        <h2 class="text-xl font-semibold leading-tight text-gray-800">
            Báo giá {{ $quote->quote_code }}
        </h2>
    </x-slot>

    <div class="py-8">
        <div class="mx-auto max-w-4xl space-y-6 px-4 sm:px-6 lg:px-8">
            <div class="rounded-lg bg-white p-6 shadow">
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200 text-sm">
                        <thead>
                            <tr class="text-left text-gray-500">
                                <th class="py-2 pr-4">Loại</th>
                                <th class="py-2 pr-4">Sản phẩm</th>
                                <th class="py-2 pr-4">SKU</th>
                                <th class="py-2 pr-4">SL</th>
                                <th class="py-2 pr-4">Đơn giá</th>
                                <th class="py-2 pr-4">Thành tiền</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-100">
                            @forelse ($quote->items as $item)
                                <tr>
                                    <td class="py-2 pr-4 text-gray-500">
                                        @if ($item->role === 'main')
                                            Sản phẩm chính
                                        @elseif ($item->role === 'addon')
                                            Sản phẩm phụ
                                        @else
                                            Phụ phí
                                        @endif
                                    </td>
                                    <td class="py-2 pr-4 font-medium text-gray-900">
                                        {{ $item->product_name ?? '—' }}
                                        @if ($item->length_cm)
                                            <span class="text-xs text-gray-500">({{ $item->length_cm }} cm)</span>
                                        @endif
                                    </td>
                                    <td class="py-2 pr-4 text-gray-500">{{ $item->sku ?? '—' }}</td>
                                    <td class="py-2 pr-4">{{ $item->quantity }}</td>
                                    <td class="py-2 pr-4">{{ number_format((float) $item->unit_price, 0, ',', '.') }} đ</td>
                                    <td class="py-2 pr-4 font-medium">{{ number_format((float) $item->line_total, 0, ',', '.') }} đ</td>
                                </tr>
                            @empty
                                <tr>
                                    <td colspan="6" class="py-4 text-gray-500">Báo giá chưa có sản phẩm nào.</td>
                                </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>

                <dl class="mt-6 grid gap-4 border-t border-gray-100 pt-4 md:grid-cols-3">
                    <div>
                        <dt class="text-sm text-gray-500">Tạm tính</dt>
                        <dd class="text-base font-medium text-gray-900">{{ number_format((float) $quote->subtotal, 0, ',', '.') }} đ</dd>
                    </div>
                    <div>
                        <dt class="text-sm text-gray-500">Phụ phí</dt>
                        <dd class="text-base font-medium text-gray-900">{{ number_format((float) $quote->fee_total, 0, ',', '.') }} đ</dd>
                    </div>
                    <div>
                        <dt class="text-sm text-gray-500">Tổng giá bộ</dt>
                        <dd class="text-lg font-semibold text-orange-600">{{ number_format((float) $quote->grand_total, 0, ',', '.') }} đ</dd>
                    </div>
                </dl>

                @if ($quote->notes)
                    <div class="mt-4 border-t border-gray-100 pt-4">
                        <dt class="text-sm text-gray-500">Ghi chú</dt>
                        <dd class="text-sm text-gray-900">{{ $quote->notes }}</dd>
                    </div>
                @endif
            </div>
        </div>
    </div>
</x-app-layout>
