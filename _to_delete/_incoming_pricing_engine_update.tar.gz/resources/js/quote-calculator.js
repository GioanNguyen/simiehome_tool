function debounce(fn, delay = 200) {
    let timer = null;

    return (...args) => {
        clearTimeout(timer);
        timer = setTimeout(() => fn(...args), delay);
    };
}

async function searchProducts(query) {
    if (query.trim().length === 0) {
        return [];
    }

    const response = await fetch(`/products/search?q=${encodeURIComponent(query)}`);

    if (!response.ok) {
        return [];
    }

    const payload = await response.json();

    return payload.data ?? [];
}

/**
 * Single Alpine component backing the whole quote form: one main product,
 * an open-ended list of add-on products, and an open-ended list of fees.
 * The subtotal/total shown here is only a client-side preview — the server
 * always recalculates through the same Pricing Engine when the quote is
 * saved, so this preview never has to be perfectly exact.
 */
function quoteForm() {
    return {
        main: {
            query: '',
            results: [],
            open: false,
            productId: null,
            sku: '',
            price: 0,
            quantity: 1,
            lengthCm: null,
        },
        addons: [],
        fees: [],

        init() {
            this.debouncedSearchMain = debounce(async () => {
                this.main.results = await searchProducts(this.main.query);
                this.main.open = this.main.results.length > 0;
            });
        },

        searchMain() {
            this.debouncedSearchMain();
        },

        selectMain(product) {
            this.main.productId = product.id;
            this.main.sku = product.sku;
            this.main.price = product.price;
            this.main.query = product.sku ? `${product.name} - ${product.sku}` : product.name;
            this.main.open = false;
        },

        clearMain() {
            this.main.productId = null;
            this.main.sku = '';
            this.main.price = 0;
            this.main.query = '';
            this.main.results = [];
        },

        addAddon() {
            const addon = {
                key: `${Date.now()}-${Math.random()}`,
                query: '',
                results: [],
                open: false,
                productId: null,
                sku: '',
                price: 0,
                quantity: 1,
            };

            addon.debouncedSearch = debounce(async () => {
                addon.results = await searchProducts(addon.query);
                addon.open = addon.results.length > 0;
            });

            this.addons.push(addon);
        },

        searchAddon(addon) {
            addon.debouncedSearch();
        },

        selectAddon(addon, product) {
            addon.productId = product.id;
            addon.sku = product.sku;
            addon.price = product.price;
            addon.query = product.sku ? `${product.name} - ${product.sku}` : product.name;
            addon.open = false;
        },

        removeAddon(index) {
            this.addons.splice(index, 1);
        },

        addFee() {
            this.fees.push({ key: `${Date.now()}-${Math.random()}`, label: '', amount: 0 });
        },

        removeFee(index) {
            this.fees.splice(index, 1);
        },

        get subtotalPreview() {
            const mainTotal = this.main.productId
                ? Number(this.main.price) * Number(this.main.quantity || 1)
                : 0;

            const addonsTotal = this.addons.reduce((sum, addon) => {
                return sum + (addon.productId ? Number(addon.price) * Number(addon.quantity || 1) : 0);
            }, 0);

            return mainTotal + addonsTotal;
        },

        get feeTotalPreview() {
            return this.fees.reduce((sum, fee) => sum + Number(fee.amount || 0), 0);
        },

        get grandTotalPreview() {
            return this.subtotalPreview + this.feeTotalPreview;
        },

        formatCurrency(value) {
            return new Intl.NumberFormat('vi-VN').format(Math.round(value || 0)) + ' đ';
        },
    };
}

window.quoteForm = quoteForm;
