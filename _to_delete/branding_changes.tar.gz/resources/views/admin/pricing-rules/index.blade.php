<x-app-layout>
    <x-slot name="header">
        <h2 class="text-xl font-semibold leading-tight text-gray-800">
            Công thức tính giá theo nhóm sản phẩm
        </h2>
    </x-slot>

    <div class="py-8">
        <div class="mx-auto max-w-5xl space-y-6 px-4 sm:px-6 lg:px-8">
            <div class="rounded-lg bg-white p-6 shadow">
                <p class="text-sm text-gray-600">
                    Mặc định mọi sản phẩm dùng <strong>catalog_price</strong> (đúng giá đã import từ CSV, không tính công thức).
                    Chỉ thêm rule bên dưới cho nhóm sản phẩm nào cần công thức khác, hoặc override riêng cho một SKU.
                </p>

                <form method="POST" action="{{ route('admin.pricing-rules.store') }}" class="mt-6 grid gap-4 border-b border-gray-100 pb-6 md:grid-cols-5">
                    @csrf

                    <div>
                        <label class="block text-xs font-medium text-gray-500">Nhóm sản phẩm (category)</label>
                        <select name="category" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm">
                            <option value="">— Áp dụng theo SKU (chọn sản phẩm) —</option>
                            @foreach ($categories as $category)
                                <option value="{{ $category }}">{{ $category }}</option>
                            @endforeach
                        </select>
                    </div>

                    <div>
                        <label class="block text-xs font-medium text-gray-500">Hoặc chỉ 1 sản phẩm (product_id)</label>
                        <input type="number" name="product_id" placeholder="ID sản phẩm (tuỳ chọn)" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm">
                    </div>

                    <div>
                        <label class="block text-xs font-medium text-gray-500">Công thức</label>
                        <select name="formula_type" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm">
                            @foreach ($formulaTypes as $formulaType)
                                <option value="{{ $formulaType }}">{{ $formulaType }}</option>
                            @endforeach
                        </select>
                    </div>

                    <div>
                        <label class="block text-xs font-medium text-gray-500">Phụ phí cố định</label>
                        <input type="number" name="surcharge_amount" min="0" value="0" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm">
                    </div>

                    <div class="flex items-end">
                        <button type="submit" class="inline-flex rounded-md bg-brand-700 px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-brand-600">
                            Thêm rule
                        </button>
                    </div>
                </form>

                <div class="mt-6 space-y-4">
                    @forelse ($pricingRules as $pricingRule)
                        <form method="POST" action="{{ route('admin.pricing-rules.update', $pricingRule) }}" class="grid gap-4 border-b border-gray-100 pb-4 md:grid-cols-6">
                            @csrf
                            @method('PATCH')

                            <div class="md:col-span-2">
                                <p class="text-sm font-medium text-gray-900">
                                    {{ $pricingRule->category ?? ($pricingRule->product?->name ?? 'Rule mặc định') }}
                                </p>
                                <p class="text-xs text-gray-500">
                                    @if ($pricingRule->product)
                                        Override riêng cho SKU {{ $pricingRule->product->sku ?? $pricingRule->product_id }}
                                    @else
                                        Áp dụng cho cả nhóm
                                    @endif
                                </p>
                            </div>

                            <div>
                                <label class="block text-xs font-medium text-gray-500">Công thức</label>
                                <select name="formula_type" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm">
                                    @foreach ($formulaTypes as $formulaType)
                                        <option value="{{ $formulaType }}" @selected($pricingRule->formula_type === $formulaType)>{{ $formulaType }}</option>
                                    @endforeach
                                </select>
                            </div>

                            <div>
                                <label class="block text-xs font-medium text-gray-500">Phụ phí</label>
                                <input type="number" name="surcharge_amount" min="0" value="{{ (float) $pricingRule->surcharge_amount }}" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm">
                            </div>

                            <label class="flex items-center gap-2 pt-6 text-sm text-gray-700">
                                <input type="checkbox" name="active" value="1" @checked($pricingRule->active)>
                                Active
                            </label>

                            <div class="pt-5">
                                <button type="submit" class="inline-flex rounded-md bg-brand-600 px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-brand-500">
                                    Lưu
                                </button>
                            </div>
                        </form>
                    @empty
                        <p class="text-sm text-gray-500">Chưa có rule nào — mọi sản phẩm đang dùng catalog_price mặc định.</p>
                    @endforelse
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
