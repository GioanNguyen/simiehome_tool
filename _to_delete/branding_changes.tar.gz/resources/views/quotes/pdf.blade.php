<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="utf-8">
    <title>Báo giá {{ $quote->quote_code }}</title>
    <style>
        @page { margin: 28px 32px; }

        body {
            font-family: DejaVu Sans, sans-serif;
            font-size: 12px;
            color: #1f2937;
        }

        .header {
            text-align: center;
            border-bottom: 2px solid #7f9675;
            padding-bottom: 10px;
            margin-bottom: 16px;
        }

        .header .logo {
            height: 48px;
        }

        .header .subtitle {
            font-size: 14px;
            font-weight: bold;
            color: #57694f;
            margin-top: 6px;
        }

        .info-table {
            width: 100%;
            margin-bottom: 16px;
        }

        .info-table td {
            padding: 2px 0;
            vertical-align: top;
        }

        .info-table .label {
            color: #6b7280;
            width: 90px;
        }

        table.items {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 16px;
        }

        table.items th {
            background: #f4f6f3;
            color: #43523d;
            text-align: left;
            padding: 6px 8px;
            border-bottom: 2px solid #7f9675;
            font-size: 11px;
            text-transform: uppercase;
        }

        table.items td {
            padding: 6px 8px;
            border-bottom: 1px solid #e5e7eb;
            font-size: 12px;
        }

        table.items .num { text-align: right; }

        .totals {
            width: 260px;
            margin-left: auto;
            margin-bottom: 16px;
        }

        .totals td {
            padding: 3px 0;
        }

        .totals .label { color: #6b7280; }
        .totals .value { text-align: right; font-weight: bold; }

        .totals .grand-total td {
            border-top: 2px solid #7f9675;
            padding-top: 6px;
            font-size: 15px;
            color: #57694f;
        }

        .notes {
            margin-top: 12px;
            padding-top: 10px;
            border-top: 1px solid #e5e7eb;
        }

        .notes .label {
            color: #6b7280;
            font-size: 11px;
            text-transform: uppercase;
            margin-bottom: 3px;
        }

        .footer {
            margin-top: 24px;
            padding-top: 10px;
            border-top: 1px solid #e5e7eb;
            font-size: 10px;
            color: #9ca3af;
            text-align: center;
        }

        .badge {
            display: inline-block;
            font-size: 9px;
            color: #43523d;
            background: #f4f6f3;
            border-radius: 3px;
            padding: 1px 4px;
            margin-left: 4px;
        }
    </style>
</head>
<body>
    <div class="header">
        @php
            $logoPath = public_path('images/logo.png');
        @endphp
        @if (is_file($logoPath))
            <img class="logo" src="data:image/png;base64,{{ base64_encode(file_get_contents($logoPath)) }}" alt="Simie Home">
        @endif
        <div class="subtitle">BÁO GIÁ</div>
    </div>

    <table class="info-table">
        <tr>
            <td class="label">Khách hàng:</td>
            <td>{{ $quote->customer_name ?? '—' }}</td>
            <td class="label">Mã báo giá:</td>
            <td>{{ $quote->quote_code }}</td>
        </tr>
        <tr>
            <td class="label">Số điện thoại:</td>
            <td>{{ $quote->customer_phone ?? '—' }}</td>
            <td class="label">Ngày báo giá:</td>
            <td>{{ $quote->created_at->format('d/m/Y') }}</td>
        </tr>
        @if ($quote->customer_email)
            <tr>
                <td class="label">Email:</td>
                <td colspan="3">{{ $quote->customer_email }}</td>
            </tr>
        @endif
        <tr>
            <td class="label">Nhân viên:</td>
            <td colspan="3">{{ $quote->user?->name ?? '—' }}</td>
        </tr>
    </table>

    <table class="items">
        <thead>
            <tr>
                <th style="width: 24px;">STT</th>
                <th>Sản phẩm</th>
                <th>Kích thước</th>
                <th class="num" style="width: 40px;">SL</th>
                <th class="num" style="width: 90px;">Đơn giá</th>
                <th class="num" style="width: 100px;">Thành tiền</th>
            </tr>
        </thead>
        <tbody>
            @php $stt = 1; @endphp
            @foreach ($quote->items->where('role', '!=', 'fee') as $item)
                <tr>
                    <td>{{ $stt++ }}</td>
                    <td>
                        {{ $item->product_name ?? '—' }}
                        @if ($item->sku)
                            <br><span style="color:#9ca3af; font-size: 10px;">SKU: {{ $item->sku }}</span>
                        @endif
                        @if ($item->role === 'addon')
                            <span class="badge">Sản phẩm phụ</span>
                        @endif
                    </td>
                    <td>{{ $item->length_cm ? $item->length_cm.' cm' : '—' }}</td>
                    <td class="num">{{ $item->quantity }}</td>
                    <td class="num">{{ number_format((float) $item->unit_price, 0, ',', '.') }} đ</td>
                    <td class="num">{{ number_format((float) $item->line_total, 0, ',', '.') }} đ</td>
                </tr>
            @endforeach

            @foreach ($quote->items->where('role', 'fee') as $item)
                <tr>
                    <td>{{ $stt++ }}</td>
                    <td>{{ $item->product_name }} <span class="badge">Phụ phí</span></td>
                    <td>—</td>
                    <td class="num">1</td>
                    <td class="num">{{ number_format((float) $item->unit_price, 0, ',', '.') }} đ</td>
                    <td class="num">{{ number_format((float) $item->line_total, 0, ',', '.') }} đ</td>
                </tr>
            @endforeach
        </tbody>
    </table>

    <table class="totals">
        <tr>
            <td class="label">Tạm tính:</td>
            <td class="value">{{ number_format((float) $quote->subtotal, 0, ',', '.') }} đ</td>
        </tr>
        <tr>
            <td class="label">Phụ phí:</td>
            <td class="value">{{ number_format((float) $quote->fee_total, 0, ',', '.') }} đ</td>
        </tr>
        <tr class="grand-total">
            <td class="label">TỔNG CỘNG:</td>
            <td class="value">{{ number_format((float) $quote->grand_total, 0, ',', '.') }} đ</td>
        </tr>
    </table>

    @if ($quote->notes)
        <div class="notes">
            <div class="label">Ghi chú</div>
            <div>{{ $quote->notes }}</div>
        </div>
    @endif

    <div class="footer">
        Báo giá được lập tự động bởi hệ thống Simie Home Calculator · In lúc {{ now()->format('d/m/Y H:i') }}<br>
        Báo giá này được tạo từ dữ liệu tại thời điểm lập, có thể thay đổi theo thoả thuận thực tế với khách hàng.
    </div>
</body>
</html>
