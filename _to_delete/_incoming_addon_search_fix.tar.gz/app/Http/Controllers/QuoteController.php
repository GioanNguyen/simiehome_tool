<?php

namespace App\Http\Controllers;

use App\Domain\Pricing\LineCalculationResult;
use App\Domain\Pricing\QuoteCalculator;
use App\Models\Quote;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\View\View;

class QuoteController extends Controller
{
    public function __construct(
        private readonly QuoteCalculator $calculator,
    ) {}

    public function index(): View
    {
        return view('quotes.index');
    }

    public function show(Quote $quote): View
    {
        $quote->load('items');

        return view('quotes.show', [
            'quote' => $quote,
        ]);
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'main.product_id' => ['nullable', 'exists:products,id'],
            'main.quantity' => ['nullable', 'integer', 'min:1'],
            'main.length_cm' => ['nullable', 'integer', 'min:1'],
            'main.unit_price_override' => ['nullable', 'numeric', 'min:0'],

            'addons' => ['array'],
            'addons.*.product_id' => ['nullable', 'exists:products,id'],
            'addons.*.quantity' => ['nullable', 'integer', 'min:1'],
            'addons.*.length_cm' => ['nullable', 'integer', 'min:1'],

            'fees' => ['array'],
            'fees.*.label' => ['nullable', 'string', 'max:255'],
            'fees.*.amount' => ['nullable', 'numeric', 'min:0'],

            'notes' => ['nullable', 'string'],
        ]);

        $result = $this->calculator->calculate($validated);

        $quote = DB::transaction(function () use ($request, $validated, $result) {
            $quote = Quote::query()->create([
                'quote_code' => 'QT-'.Str::upper(Str::random(8)),
                'user_id' => $request->user()->id,
                'subtotal' => $result->subtotal,
                'fee_total' => $result->feeTotal,
                'grand_total' => $result->grandTotal,
                'notes' => $validated['notes'] ?? null,
            ]);

            $position = 0;

            if ($result->main !== null) {
                $this->createItem($quote, 'main', $result->main, $position++);
            }

            foreach ($result->addons as $addon) {
                $this->createItem($quote, 'addon', $addon, $position++);
            }

            foreach ($result->fees as $fee) {
                $quote->items()->create([
                    'role' => 'fee',
                    'product_name' => $fee['label'],
                    'unit_price' => $fee['amount'],
                    'quantity' => 1,
                    'line_total' => $fee['amount'],
                    'position' => $position++,
                ]);
            }

            return $quote;
        });

        return redirect()->route('quotes.show', $quote);
    }

    private function createItem(Quote $quote, string $role, LineCalculationResult $line, int $position): void
    {
        $quote->items()->create([
            'role' => $role,
            'product_id' => $line->productId,
            'product_name' => $line->productName,
            'sku' => $line->sku,
            'category' => $line->category,
            'unit_price' => $line->unitPrice,
            'quantity' => $line->quantity,
            'length_cm' => $line->lengthCm,
            'surcharge' => $line->surcharge,
            'formula_type' => $line->formulaType,
            'line_total' => $line->lineTotal,
            'position' => $position,
        ]);
    }
}
