<?php

namespace Tests\Unit\Domain\Pricing;

use App\Domain\Pricing\QuoteCalculator;
use App\Models\PricingRule;
use App\Models\Product;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class QuoteCalculatorTest extends TestCase
{
    use RefreshDatabase;

    public function test_it_uses_the_catalog_price_by_default_for_the_main_item(): void
    {
        $table = Product::factory()->create([
            'category' => 'Bàn - Tables',
            'regular_price' => 1_850_000,
            'sale_price' => 1_665_000,
        ]);

        $calculator = new QuoteCalculator;

        $result = $calculator->calculate([
            'main' => ['product_id' => $table->id, 'quantity' => 1],
        ]);

        // Sale price wins when set.
        $this->assertSame(1_665_000.0, $result->main->unitPrice);
        $this->assertSame(1_665_000.0, $result->subtotal);
        $this->assertSame(1_665_000.0, $result->grandTotal);
    }

    public function test_it_applies_a_length_ratio_rule_configured_for_the_category(): void
    {
        $table = Product::factory()->create([
            'category' => 'Bàn - Tables',
            'regular_price' => 4_000_000,
            'sale_price' => null,
        ]);

        PricingRule::query()->create([
            'category' => 'Bàn - Tables',
            'formula_type' => 'length_ratio',
            'surcharge_amount' => 500_000,
            'active' => true,
        ]);

        $calculator = new QuoteCalculator;

        $result = $calculator->calculate([
            'main' => ['product_id' => $table->id, 'quantity' => 1, 'length_cm' => 140],
        ]);

        // 4_000_000 * 140 / 100 + 500_000
        $this->assertSame(6_100_000.0, $result->main->lineTotal);
    }

    public function test_it_totals_an_arbitrary_number_of_addon_products_and_fees(): void
    {
        $table = Product::factory()->create(['regular_price' => 1_000_000, 'sale_price' => null]);
        $chairA = Product::factory()->create(['regular_price' => 500_000, 'sale_price' => null]);
        $chairB = Product::factory()->create(['regular_price' => 300_000, 'sale_price' => null]);
        $mirror = Product::factory()->create(['regular_price' => 200_000, 'sale_price' => null]);

        $calculator = new QuoteCalculator;

        $result = $calculator->calculate([
            'main' => ['product_id' => $table->id, 'quantity' => 1],
            'addons' => [
                ['product_id' => $chairA->id, 'quantity' => 4],
                ['product_id' => $chairB->id, 'quantity' => 2],
                ['product_id' => $mirror->id, 'quantity' => 1],
            ],
            'fees' => [
                ['label' => 'Phí ship', 'amount' => 300_000],
                ['label' => 'Phí lắp đặt', 'amount' => 200_000],
            ],
        ]);

        $this->assertCount(3, $result->addons);
        // 1_000_000 + (500_000*4) + (300_000*2) + 200_000 = 3_800_000
        $this->assertSame(3_800_000.0, $result->subtotal);
        $this->assertSame(500_000.0, $result->feeTotal);
        $this->assertSame(4_300_000.0, $result->grandTotal);
    }

    public function test_a_manual_price_override_replaces_the_engine_and_ignores_category_rules(): void
    {
        $table = Product::factory()->create([
            'category' => 'Bàn - Tables',
            'regular_price' => 4_000_000,
            'sale_price' => null,
        ]);

        // Even with a surcharge-heavy category rule in place, the override
        // must win outright — no engine, no surcharge on top of it.
        PricingRule::query()->create([
            'category' => 'Bàn - Tables',
            'formula_type' => 'length_ratio',
            'surcharge_amount' => 500_000,
            'active' => true,
        ]);

        $calculator = new QuoteCalculator;

        $result = $calculator->calculate([
            'main' => [
                'product_id' => $table->id,
                'quantity' => 2,
                'unit_price_override' => 3_500_000,
            ],
        ]);

        $this->assertSame('manual_override', $result->main->formulaType);
        $this->assertSame(3_500_000.0, $result->main->unitPrice);
        $this->assertSame(0.0, $result->main->surcharge);
        $this->assertSame(7_000_000.0, $result->main->lineTotal);
    }

    public function test_an_empty_override_falls_back_to_the_engine(): void
    {
        $table = Product::factory()->create(['regular_price' => 1_000_000, 'sale_price' => null]);

        $calculator = new QuoteCalculator;

        $result = $calculator->calculate([
            'main' => ['product_id' => $table->id, 'quantity' => 1, 'unit_price_override' => ''],
        ]);

        $this->assertSame('catalog_price', $result->main->formulaType);
        $this->assertSame(1_000_000.0, $result->main->unitPrice);
    }

    public function test_it_allows_saving_a_quote_with_no_main_product(): void
    {
        $calculator = new QuoteCalculator;

        $result = $calculator->calculate([
            'fees' => [['label' => 'Phí tư vấn', 'amount' => 100_000]],
        ]);

        $this->assertNull($result->main);
        $this->assertSame(0.0, $result->subtotal);
        $this->assertSame(100_000.0, $result->grandTotal);
    }
}
