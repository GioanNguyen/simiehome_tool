# Quotation Tool

Laravel tool noi bo de sales/admin tinh nhanh gia bo ban an, dong bo san pham tu WooCommerce, va luu lich su bao gia.

## Requirements

- PHP 8.3
- Composer
- Node.js + npm
- MySQL cho production; SQLite co the dung cho local/test nhanh
- Goi `barryvdh/laravel-dompdf` (dung de xuat PDF bao gia) — xem buoc cai o phan Local Setup

## Features

- Dang nhap noi bo bang Laravel Breeze
- Import san pham tu file CSV export (Admin upload hoac Artisan command), khong can goi API
- Tim san pham theo `name` hoac `sku`
- Pricing Engine linh hoat theo nhom san pham (catalog price, length ratio, fixed price, quantity), quan ly cong thuc trong admin
- Bao gia gom 1 san pham chinh + so luong tuy y san pham phu + phu phi
- Man hinh xac nhan truoc khi luu: co the "Quay lai" sua ma khong mat du lieu da nhap, nhap thong tin khach hang (ten/SDT/email)
- Xuat file PDF bao gia tu snapshot da luu (khong tinh lai theo gia hien tai)
- Danh sach bao gia tim kiem theo ngay / nguoi bao gia / ten hoac SDT khach hang, co phan trang (10/20/50)
- Dong bo catalog WooCommerce vao database Laravel (tuy chon, thay the duoc bang CSV import)
- Quan ly sync runs va pricing rules trong admin
- Phan quyen theo vai tro (Admin / Sales / Manager) — xem muc "Phan quyen (RBAC)" ben duoi

## Local Setup

1. `composer install`
2. `composer require barryvdh/laravel-dompdf` (can cho tinh nang xuat PDF bao gia)
3. `cp .env.example .env`
4. `php artisan key:generate`
5. `touch database/database.sqlite`
6. `php artisan migrate`
7. `npm install`
8. `npm run build`
9. `php artisan serve`

## Cap nhat khi pull code moi (khong phai cai lai tu dau)

Sau khi pull nhung thay doi ve man hinh xac nhan / xuat PDF / danh sach bao gia
(va cac ban fix sau do), chay theo thu tu sau. Du lieu san pham / bao gia / quy
tac gia dang co se **khong bi mat** — cac migration moi chi them cot, khong
migrate:fresh.

1. `composer require barryvdh/laravel-dompdf` — chi can chay 1 lan neu chua
   cai (kiem tra nhanh: mo `composer.json`, neu da co dong
   `"barryvdh/laravel-dompdf"` trong `require` thi bo qua buoc nay, chi can
   `composer install`).
2. `php artisan migrate` — ap dung cac migration moi: them cot
   `customer_name`, `customer_phone`, `customer_email` vao bang `quotes`,
   va them cot `role` vao bang `users` (xem muc "Phan quyen (RBAC)" —
   migration nay **tu dong gan role `admin` cho user dau tien** trong bang
   `users` de luon co it nhat 1 tai khoan vao duoc `/admin/users`, cac user
   con lai mac dinh la `sales`).
3. `npm run build` — build lai file JS (`quote-calculator.js` thay doi qua
   moi ban cap nhat: man hinh xac nhan, prefill khi "Quay lai", fix mat
   kich thuoc tuy chinh).
4. (Tuy chon nhung nen lam) `php artisan view:clear` — xoa cache Blade cu
   neu thay man hinh khong len giao dien moi sau khi pull.
5. (Tuy chon) `php artisan test` — chay lai bo test (75 test) de xac nhan
   moi thu van hoat dong dung tren may minh.
6. `php artisan serve` — chay lai server nhu binh thuong.

Neu tung chay `php artisan serve` truoc do, nen tat process cu (Ctrl+C hoac
`pkill -f "artisan serve"`) roi chay lai o buoc 6 de chac chan dang dung code
moi nhat.

Sau khi migrate xong, dang nhap bang tai khoan vua duoc gan `admin`, vao
`/admin/users` de gan role dung cho tung nguoi (xem muc ben duoi).

## WooCommerce Config

Cap nhat cac bien sau trong `.env`:

```dotenv
WOOCOMMERCE_BASE_URL=https://your-site.com
WOOCOMMERCE_KEY=ck_xxxxx
WOOCOMMERCE_SECRET=cs_xxxxx
```

## Phan quyen (RBAC)

3 vai tro, gan qua cot `users.role` — dung theo de xuat trong tai lieu y
tuong (`§17. Phan quyen`):

| Vai tro   | Duoc lam gi |
|-----------|-------------|
| `admin`   | Toan quyen: import/quan ly san pham, cong thuc gia, dong bo WooCommerce, xem **tat ca** bao gia, doi vai tro nguoi dung tai `/admin/users`. |
| `sales`   | Tao bao gia; chi xem/xuat PDF **bao gia do chinh minh tao** (`/quotes` chi liet ke bao gia cua ho, mo bao gia cua nguoi khac se bi chan 403). Khong vao duoc man hinh `/admin/*` nao. |
| `manager` | Xem **tat ca** bao gia (giong admin, chi doc), khong vao duoc `/admin/*` (khong quan ly catalog/cong thuc gia/nguoi dung). |

Cach gan vai tro: dang nhap bang tai khoan admin → menu → **Người dùng**
(`/admin/users`) → chon vai tro trong dropdown → **Lưu**. Mot admin khong
the tu doi vai tro cua chinh minh (tranh tu khoa minh khoi he thong) — nho
mot admin khac doi giup, hoac sua truc tiep trong database.

Tai khoan seed mac dinh (`test@example.com`) la `admin`. Neu nang cap tu
database da co san (khong chay seeder), migration
`2026_08_20_100000_add_role_to_users_table` se tu dong gan `admin` cho user
co `id` nho nhat, con lai mac dinh `sales`.

**Chua lam** (tai lieu `§17` co nhac nhung chua co tinh nang goc de gan
quyen vao — se can khi tinh nang tuong ung duoc xay):

- Sua bao gia da luu (hien tai bao gia chi tao 1 lan, khong co man hinh sua).
- Nhan ban bao gia.
- Quy trinh duyet bao gia (can them cot trang thai: Draft/Sent/Approved...).
- Man hinh bao cao rieng cho Manager.

## Main Routes

- `/quotes`: danh sach bao gia (tim kiem theo ngay / nguoi bao gia / khach hang, phan trang; Sales chi thay bao gia cua minh)
- `/quotes/create`: man hinh tinh gia (chon san pham chinh + phu + phu phi)
- `/quotes/confirm`: man hinh xac nhan (nhap thong tin khach hang, "Quay lai" de sua)
- `/quotes/{quote}`: chi tiet 1 bao gia da luu (chi chu bao gia hoac admin/manager moi xem duoc)
- `/quotes/{quote}/pdf`: xuat PDF bao gia tu snapshot da luu (cung gioi han nhu tren)
- `/products/search`: endpoint JSON cho goi y san pham
- `/admin/product-imports`: upload file CSV de import/cap nhat san pham (Admin)
- `/admin/sync-runs`: xem va chay sync WooCommerce (Admin)
- `/admin/pricing-rules`: chinh cong thuc gia theo nhom san pham hoac tung SKU (Admin)
- `/admin/users`: doi vai tro nguoi dung (Admin)

## Verification

- `php artisan test`
- `npm run build`
