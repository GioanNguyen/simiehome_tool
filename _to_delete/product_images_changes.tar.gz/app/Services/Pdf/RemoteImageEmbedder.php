<?php

namespace App\Services\Pdf;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;
use Throwable;

/**
 * Fetches a remote product image (from the catalog's WooCommerce-hosted
 * URL) and turns it into a base64 data: URI so dompdf can render it
 * without needing its own "remote enabled" fetching turned on — dompdf
 * fetching arbitrary URLs itself is an SSRF-style risk we'd rather not
 * carry, and a data URI also survives even if the image host is slow or
 * briefly unreachable at print time (the quote just prints without that
 * one picture instead of failing the whole PDF).
 *
 * One instance is meant to live for the lifetime of a single PDF render —
 * it memoizes by URL so the same product photo (e.g. reused as both main
 * item and an addon) is only fetched once per request.
 */
class RemoteImageEmbedder
{
    private const MAX_BYTES = 2 * 1024 * 1024; // 2 MB safety cap

    private const TIMEOUT_SECONDS = 4;

    /** @var array<string, string|null> */
    private array $cache = [];

    public function toDataUri(?string $url): ?string
    {
        if ($url === null || $url === '') {
            return null;
        }

        if (array_key_exists($url, $this->cache)) {
            return $this->cache[$url];
        }

        return $this->cache[$url] = $this->fetch($url);
    }

    private function fetch(string $url): ?string
    {
        if (! Str::startsWith($url, ['http://', 'https://'])) {
            return null;
        }

        try {
            $response = Http::timeout(self::TIMEOUT_SECONDS)->get($url);
        } catch (Throwable) {
            return null;
        }

        if (! $response->successful()) {
            return null;
        }

        $body = $response->body();

        if ($body === '' || strlen($body) > self::MAX_BYTES) {
            return null;
        }

        $mime = $response->header('Content-Type') ?: 'image/jpeg';
        $mime = Str::before($mime, ';'); // strip a trailing "; charset=..." if present

        if (! Str::startsWith($mime, 'image/')) {
            return null;
        }

        return 'data:'.$mime.';base64,'.base64_encode($body);
    }
}
